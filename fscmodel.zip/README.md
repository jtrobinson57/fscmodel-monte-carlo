# fscmodel

Fuel Supply Chain Model

note: capex is currently not calculated
